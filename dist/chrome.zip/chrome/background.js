/*chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    return {cancel: details.url.indexOf("://musiqpad.com/pads/lib/js/app.js") != -1};
  },
  {urls: ["<all_urls>"]},
  ["blocking"]);
*/

function fn() {
  if (typeof API === 'object' && typeof API.DATA !== 'undefined' && typeof musiqplus == 'undefined') {
    $.getJSON('https://explodingcamera.xyz/musiqplus/version.json', function (data) {
        if (typeof data.version != 'undefined') {
          $.getScript('https://explodingcamera.xyz/musiqplus/app-' + data.version + '.js');
        }
      });
  }
}

var script = document.createElement('script');
script[script.innerText ? 'innerText' : 'textContent'] = '(' + fn + ')()';
(document.head || document.documentElement).appendChild(script);
script.parentNode.removeChild(script);
